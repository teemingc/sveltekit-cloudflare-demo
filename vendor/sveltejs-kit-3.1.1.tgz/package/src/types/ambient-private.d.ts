/** Internal version of $app/server */
declare module '<sveltekit:generated>/server.js' {
	import { SSROptions, ServerHooks } from 'types';

	export const options: SSROptions;
	export function get_hooks(): Promise<Partial<ServerHooks>>;
}

/** the dev manifest as code, for @sveltejs/kit/adapter/dev */
declare module '<sveltekit:generated>/server-manifest.js' {
	export const assets: string;
	export const instrumentation: (() => Promise<unknown>) | null;
	export const manifest: import('types').SSRManifest;
}

/** where code outside the vite process can reach the vite dev server */
declare module '<sveltekit:generated>/origin.js' {
	export const origin: string;
}

declare module '<sveltekit:generated>/env/config.js' {
	// exported environment variables are defined in env.d.ts

	/** Populate exported environment variables */
	export function set_env(environment: Record<string, string | undefined>): void;

	/** public env vars */
	export const explicit_public_env: Record<string, any>;

	/** public env vars that should be inlined when a page is rendered */
	export const rendered_env: Record<string, any>;
}

declare module '<sveltekit:generated>/env/private/server.js' {
	// exported environment variables are defined in env.d.ts
}

declare module '<sveltekit:generated>/env/public/client.js' {
	// exported environment variables are defined in env.d.ts
}

declare module '<sveltekit:generated>/env/public/server.js' {
	// exported environment variables are defined in env.d.ts
}

/** Internal version of $app/manifest */
declare module '<sveltekit:generated>/app-manifest.js' {
	export const immutable: Array<{ path: string }>;
	export const assets: Array<{ path: string }>;
	export const prerendered: Array<{ path: string }>;
	export const routes: Array<{ id: string; page: boolean; endpoint: boolean }>;
}
