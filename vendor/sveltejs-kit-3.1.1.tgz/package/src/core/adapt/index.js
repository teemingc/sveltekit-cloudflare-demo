import { styleText } from 'node:util';
import { create_builder } from './builder.js';
import * as w from '../../messages/build-warnings.js';

/**
 * @param {import('types').ValidatedConfig} config
 * @param {import('types').BuildData} build_data
 * @param {import('types').ServerMetadata} server_metadata
 * @param {import('types').Prerendered} prerendered
 * @param {import('types').PrerenderMap} prerender_map
 * @param {typeof import('$app/manifest')} app_manifest
 * @param {import('types').Logger} log
 * @param {import('types').RemoteChunk[]} remotes
 * @param {import('vite').ResolvedConfig} vite_config
 * @param {Record<string, import('@sveltejs/kit/env').EnvVarConfig<any>> | null} explicit_env_config
 */
export async function adapt(
	config,
	build_data,
	server_metadata,
	prerendered,
	prerender_map,
	app_manifest,
	log,
	remotes,
	vite_config,
	explicit_env_config
) {
	const { name, adapt } = config.adapter;

	console.log(styleText(['bold', 'cyan'], `\n> Using ${name}`));

	let warned = false;

	const builder = create_builder({
		config: {
			...config,
			get kit() {
				if (!warned) {
					warned = true;
					w.adapter_config_kit_deprecated();
				}

				return config;
			}
		},
		build_data,
		server_metadata,
		route_data: build_data.manifest_data.routes.filter((route) => route.page || route.endpoint),
		prerendered,
		prerender_map,
		app_manifest,
		log,
		remotes,
		vite_config,
		explicit_env_config
	});

	await adapt(builder);

	log.success('done');
}
