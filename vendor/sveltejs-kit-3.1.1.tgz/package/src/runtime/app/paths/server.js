import { base, assets, relative } from './internal/server.js';
import { resolve_route, find_route } from '../../../utils/routing.js';
import { decode_pathname, has_scheme_or_authority } from '../../../utils/url.js';
import { try_get_request_store } from '@sveltejs/kit/internal/server';
import { manifest } from '../../server/internal.js';
import { get_hooks } from '<sveltekit:generated>/server.js';
import { DEV } from 'esm-env';
import * as e from '../../../messages/shared-errors.js';
import * as w from '../../../messages/shared-warnings.js';

export { base, assets, app_dir } from './internal/server.js';

/** @type {typeof import('./client.js').asset} */
export function asset(file) {
	// TODO 4.0 remove this
	if (file[0] === '/') {
		if (DEV) {
			w.asset_leading_slash({ path: file, fixed: file.slice(1) });
		}

		file = file.slice(1);
	}

	return assets !== base ? `${assets}/${file}` : prefix_path('/' + file);
}

/** @type {typeof import('./client.js').resolve} */
export function resolve(id, params) {
	if (has_scheme_or_authority(id)) {
		e.resolve_url_input({ id });
	}

	let resolved;

	if (id[0] === '/') {
		// route ID
		if (id.includes('[') && !params) {
			e.resolve_params_missing({ id });
		}

		resolved = resolve_route(id, params ?? {});
	} else {
		resolved = '/' + id;
	}

	return prefix_path(resolved);
}

/** @param {string} resolved */
function prefix_path(resolved) {
	if (relative) {
		const store = try_get_request_store();

		if (store && !store.state.prerendering?.fallback) {
			const after_base = store.event.url.pathname.slice(base.length);
			const segments = after_base.split('/').slice(2);
			const prefix = segments.map(() => '..').join('/') || '.';

			return prefix + resolved;
		}
	}

	return base + resolved;
}

/** @type {typeof import('./client.js').match} */
export async function match(url) {
	const store = try_get_request_store();

	if (typeof url === 'string') {
		const origin = store?.event.url.origin ?? 'a://a';
		url = new URL(url, origin);
	}

	const { reroute } = await get_hooks();

	let resolved_path;

	try {
		resolved_path = decode_pathname(
			(await reroute?.({ url: new URL(url), fetch: store?.event.fetch ?? fetch })) ?? url.pathname
		);
	} catch {
		return null;
	}

	if (base && resolved_path.startsWith(base)) {
		resolved_path = resolved_path.slice(base.length) || '/';
	}

	const matchers = await manifest.matchers();
	const result = find_route(resolved_path, manifest.routes, matchers);

	if (result) {
		return {
			id: /** @type {import('$app/types').RouteId} */ (result.route.id),
			params: result.params
		};
	}

	return null;
}
