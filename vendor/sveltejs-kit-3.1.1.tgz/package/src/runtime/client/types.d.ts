import {
	ClientHooks,
	CSRPageNode,
	CSRPageNodeLoader,
	CSRRoute,
	CSRRouteServer,
	ServerDataNode,
	TrailingSlash,
	Uses
} from 'types';
import { ParamMatcher } from '@sveltejs/kit/params';
import { Page } from '$app/state';
import { RenderNode } from '../props.svelte.js';

export interface SvelteKitApp {
	/**
	 * A list of all the error/layout/page nodes used in the app.
	 * - In case of router.resolution=client, this is filled completely upfront.
	 * - In case of router.resolution=server, this is filled with the root layout and root error page
	 *   at the beginning and then filled up as the user navigates around the app, loading new nodes
	 */
	nodes: CSRPageNodeLoader[];

	/**
	 * A list of all layout node ids that have a server load function.
	 * Pages are not present because it's shorter to encode it on the leaf itself.
	 *
	 * In case of router.resolution=server, this only contains one entry for the root layout.
	 */
	server_loads: number[];

	/**
	 * A map of `[routeId: string]: [leaf, layouts, errors]` tuples, which
	 * is parsed into an array of routes on startup. The numbers refer to the indices in `nodes`.
	 * If the leaf number is negative, it means it does use a server load function and the complement is the node index.
	 * The route layout and error nodes are not referenced, they are always number 0 and 1 and always apply.
	 *
	 * In case of router.resolution=server, this object is empty, as resolution happens on the server.
	 */
	dictionary: Record<string, [leaf: number, layouts: number[], errors?: number[]]>;

	/**
	 * A map of `[matcherName: string]: ParamMatcher`, which is used to match and parse route parameters.
	 *
	 * In case of router.resolution=server, this object is empty, as resolution happens on the server.
	 */
	matchers: Record<string, ParamMatcher>;

	hooks: ClientHooks;

	decode: (type: string, value: any) => any;

	decoders: Record<string, (data: any) => any>;
	encoders: Record<string, (data: any) => any>;

	/**
	 * Whether or not we're using hash-based routing
	 */
	hash: boolean;

	/**
	 * Lazily loads the contents of src/error.html, used as a last-resort
	 * error page when the root layout's load function throws during client-side rendering.
	 */
	get_error_template: () => Promise<(data: { status: number; message: string }) => string>;
}

export type NavigationIntent = {
	/** `url.pathname + url.search`  */
	id: string;
	/** Whether we are invalidating or navigating */
	invalidating: boolean;
	/** The route parameters */
	params: Record<string, string>;
	/** The route that matches `path` */
	route: CSRRoute;
	/** The destination URL */
	url: URL;
};

export type NavigationResult = NavigationRedirect | NavigationFinished;

export type NavigationRedirect = {
	type: 'redirect';
	status: number;
	location: string;
};

export type NavigationFinished = {
	type: 'loaded';
	state: NavigationState;
	props: {
		page: Page;
		form?: Record<string, any> | null;
		error?: App.Error;
		tree: RenderNode;
	};
};

export type BranchNode = {
	node: CSRPageNode;
	loader: CSRPageNodeLoader;
	server: DataNode | null;
	universal: DataNode | null;
	data: Record<string, any> | null;
	slash?: TrailingSlash;
};

export interface DataNode {
	type: 'data';
	data: Record<string, any> | null;
	uses: Uses;
	slash?: TrailingSlash;
}

export interface NavigationState {
	branch: Array<BranchNode | undefined>;
	error: App.Error | null;
	params: Record<string, string>;
	route: CSRRoute | null;
	url: URL;
}

export interface HydrateOptions {
	/** Provided in the case of a form action that returns `fail`, but otherwise derived from `error` */
	status?: number;
	error: App.Error | null;
	node_ids: number[];
	params: Record<string, string>;
	route: { id: string | null };
	/** Only used when `router.resolution=server`; can then still be undefined in case of 404 */
	server_route?: CSRRouteServer;
	data: Array<ServerDataNode | null>;
	form: Record<string, any> | null;
	/** The results of all remote functions executed during SSR so that they can be reused during hydration */
	remote: Record<string, any>;
}
