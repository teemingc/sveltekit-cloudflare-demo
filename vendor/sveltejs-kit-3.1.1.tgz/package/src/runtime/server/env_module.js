import * as devalue from 'devalue';
import { rendered_env } from '<sveltekit:generated>/env/config.js';

/** @type {string} */
let payload;

/** @type {string} */
let etag;

/** @type {Headers} */
let headers;

/**
 * @param {Request} request
 * @returns {Response}
 */
export function get_public_env(request) {
	const env = rendered_env;

	payload ??= devalue.uneval(env);
	etag ??= `W/${Date.now()}`;
	headers ??= new Headers({
		'content-type': 'application/javascript; charset=utf-8',
		etag
	});

	if (request.headers.get('if-none-match') === etag) {
		return new Response(undefined, { status: 304, headers });
	}

	return new Response(`export const env=${payload}`, { headers });
}
