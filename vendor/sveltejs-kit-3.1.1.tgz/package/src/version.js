// generated during release, do not modify

/** @type {string} */
export const VERSION = '3.1.1';
